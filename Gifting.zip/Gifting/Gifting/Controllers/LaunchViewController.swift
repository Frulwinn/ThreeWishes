//
//  LaunchViewController.swift
//  Gifting
//
//  Created by Lambda_School_Loaner_34 on 3/22/19.
//  Copyright © 2019 Frulwinn. All rights reserved.
//

import UIKit

class LaunchViewController: UIViewController {
    
    //MARK: - Properties

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
  
}
